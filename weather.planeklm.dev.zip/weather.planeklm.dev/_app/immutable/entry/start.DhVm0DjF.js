import {
    a as t
} from "../chunks/entry.Bej1XVqJ.js";
export {
    t as start
};